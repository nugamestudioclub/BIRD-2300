using UnityEngine;

public class InnerPlayerController : MonoBehaviour
{
    public int maxHealth;
    private int currentHealth;



    //shooting controls



    //interaction controls (press e when next to and looking at interactable object)
    //collect
}
